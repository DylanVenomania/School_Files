﻿-- 23110186 Tôn Hoàng Cầm
create database Cosodulieu_tuan4_Gara;
go

use Cosodulieu_tuan4_Gara;
go


create table tho (
    matho int primary key,
    tentho nvarchar(255) not null,
    nhom int not null,
    nhomtruong int not null
);


create table congviec (
    macv int primary key,
    noidungcv nvarchar(255) not null
);


create table khachhang (
    makh int primary key,
    tenkh nvarchar(255) not null,
    diachi nvarchar(255),
    dienthoai nvarchar(20)
);


create table hopdong (
    sohd int primary key,
    ngayhd date not null,
    makh int not null,
    soxe nvarchar(50) not null,
    trigiahd decimal(10,2),
    ngaygiaodk date not null,
    ngayngthu date,
    foreign key (makh) references khachhang(makh)
);


create table chitiet_hd (
    sohd int not null,
    macv int not null,
    trigiacv decimal(10,2),
    matho int not null,
    khoantho decimal(10,2),
    primary key (sohd, macv),
    foreign key (sohd) references hopdong(sohd),
    foreign key (macv) references congviec(macv),
    foreign key (matho) references tho(matho)
);


create table phieuthu (
    sopt int primary key,
    ngaylappt date not null,
    sohd int not null,
    makh int not null,
    hoten nvarchar(255),
    sotienthu decimal(10,2),
    foreign key (sohd) references hopdong(sohd),
    foreign key (makh) references khachhang(makh)
);



insert into tho (matho, tentho, nhom, nhomtruong) values
(1, 'nguyen van a', 101, 1),
(2, 'tran thi b', 101, 1),
(3, 'le van c', 102, 3),
(4, 'pham van d', 103, 4),
(5, 'hoang thi e', 102, 3);

insert into congviec (macv, noidungcv) values
(10, 'thay nhot dong co'),
(20, 'thay lop xe'),
(30, 'son lai than xe'),
(40, 'sua he thong phanh'),
(50, 'can chinh dong co');

insert into khachhang (makh, tenkh, diachi, dienthoai) values
(1001, 'nguyen van k', 'ha noi', '0912345678'),
(1002, 'tran thi l', 'hai phong', '0987654321'),
(1003, 'le van m', 'da nang', '0933445566'),
(1004, 'pham van n', 'tp hcm', '0977889900');

insert into hopdong (sohd, ngayhd, makh, soxe, trigiahd, ngaygiaodk, ngayngthu) values
(5001, '2024-03-01', 1001, '30a-12345', 5000000, '2024-03-05', '2024-03-06'),
(5002, '2024-03-02', 1002, '29b-67890', 7000000, '2024-03-07', null),
(5003, '2024-03-03', 1003, '43c-56789', 3000000, '2024-03-10', '2024-03-12'),
(5004, '2024-03-04', 1004, '51d-11122', 6000000, '2024-03-08', null),
(6000, '2002-12-01', 1001, '30A-88888', 5000000, '2002-12-20', null);

insert into chitiet_hd (sohd, macv, trigiacv, matho, khoantho) values
(5001, 10, 1000000, 1, 700000),
(5001, 20, 2000000, 2, 1500000),
(5002, 30, 2500000, 3, 1800000),
(5002, 40, 1500000, 4, 1000000),
(5003, 50, 3000000, 5, 2500000),
(5004, 10, 1000000, 1, 700000),
(5004, 30, 2000000, 2, 1500000);


insert into phieuthu (sopt, ngaylappt, sohd, makh, hoten, sotienthu) values
(9001, '2024-03-06', 5001, 1001, 'nguyen van k', 5000000),
(9002, '2024-03-10', 5003, 1003, 'le van m', 1500000),
(9003, '2024-03-11', 5003, 1003, 'le van m', 1500000),
(9004, '2024-03-15', 5002, 1002, 'tran thi l', 3000000);

