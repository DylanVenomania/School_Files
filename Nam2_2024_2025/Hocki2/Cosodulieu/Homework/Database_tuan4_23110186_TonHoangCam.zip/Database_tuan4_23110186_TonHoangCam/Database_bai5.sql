﻿-- 23110186 Tôn Hoàng Cầm
create database cosodulieu_tuan4_truongpt;
go

use cosodulieu_tuan4_truongpt;
go


create table gv (
    magv int primary key,
    tengv nvarchar(255) not null,
    mamh int null  -- null nếu giáo viên không chủ nhiệm môn nào
);


create table mhoc (
    mamh int primary key,
    tenmh nvarchar(255) not null,
    sotiet int not null
);


create table buoithi (
    hky int not null,
    ngay date not null,
    gio time not null,
    phg nvarchar(10) not null,
    mamh int not null,
    tgthi int not null, -- đơn vị phút
    primary key (hky, ngay, gio, phg),
    foreign key (mamh) references mhoc(mamh)
);


create table pc_coi_thi (
    magv int not null,
    hky int not null,
    ngay date not null,
    gio time not null,
    phg nvarchar(10) not null,
    primary key (magv, hky, ngay, gio, phg),
    foreign key (magv) references gv(magv),
    foreign key (hky, ngay, gio, phg) references buoithi(hky, ngay, gio, phg)
);


insert into gv (magv, tengv, mamh) 
values
(1, 'nguyen van a', 101),
(2, 'tran thi b', 102),
(3, 'le van c', null),
(4, 'pham van d', null),
(5, 'hoang thi e', 103);


insert into mhoc (mamh, tenmh, sotiet) 
values
(101, 'toan', 60),
(102, 'van hoc', 45),
(103, 'ly', 30),
(104, 'hoa', 50);

insert into buoithi (hky, ngay, gio, phg, mamh, tgthi) 
values
(1, '2024-06-10', '08:00', '101', 101, 150),
(1, '2024-06-10', '10:00', '102', 102, 150),
(1, '2024-06-11', '08:00', '103', 103, 120),
(2, '2024-12-20', '14:00', '104', 104, 150);

insert into pc_coi_thi (magv, hky, ngay, gio, phg) 
values
(3, 1, '2024-06-10', '08:00', '101'),
(4, 1, '2024-06-10', '10:00', '102'),
(5, 1, '2024-06-11', '08:00', '103');




