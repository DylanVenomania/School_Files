﻿-- 23110186 Tôn Hoàng Cầm
create database Cosodulieu_tuan4_QLThuVien;
go

use Cosodulieu_tuan4_QLThuVien;
go

create table NXB(
	MaNXB varchar (10 ) not null primary key,
	TenNXB nvarchar(100) not null,
	DiaChi nvarchar( 255 ) not null,
	Sdt varchar ( 15 )
);

insert into NXB (MaNXB, TenNXB, DiaChi, Sdt) 
values
    ('NXB01', 'Addison Wesley', 'New York, USA', '123456789'),
    ('NXB02', 'OReilly Media', 'California, USA', '987654321'),
    ('NXB03', 'Springer', 'Berlin, Germany', '555444333');




create table DauSach(
	MaSach varchar( 10 ) primary key,
	Tua nvarchar( 255 ) not null,
	MaNXB varchar(10) not null, 
	
	foreign key (MaNXB ) references NXB( MaNXB ) 
	on delete cascade on update cascade 
);

insert into DauSach (MaSach, Tua, MaNXB) 
values
    ('S001', 'Learning Python', 'NXB01'),
    ('S002', 'Data Science Handbook', 'NXB02'),
    ('S003', 'Machine Learning Basics', 'NXB03'),
    ('S004', 'Programming in C', 'NXB01'),
    ('S005', 'Algorithms Unlocked', 'NXB01');




create table TacGia( 
	MaSach varchar(10 ) not null,
	TenTacGia nvarchar(100) not null,
	primary key ( MaSach, TenTacGia),
	foreign key ( MaSach) references DauSach(MaSach) on delete cascade on update cascade
);

insert into TacGia (MaSach, TenTacGia) 
values
    ('S001', 'Mark Lutz'),
    ('S002', 'Jake VanderPlas'),
    ('S003', 'Andrew Ng'),
    ('S004', 'Dennis Ritchie'),
    ('S005', 'Hemingway'),
    ('S001', 'Hemingway');




create table CuonSach(
	MaSach varchar(10) not null,
	MaCuon varchar( 10 ) primary key,
	ViTri nvarchar(100) not null,
	foreign key (MaSach) references DauSach( MaSach ) on delete cascade on update cascade
);

insert into CuonSach (MaSach, MaCuon, ViTri) 
values
    ('S001', 'C001', 'Kệ A1'),
    ('S001', 'C002', 'Kệ A1'),
    ('S002', 'C003', 'Kệ B2'),
    ('S003', 'C004', 'Kệ C3'),
    ('S004', 'C005', 'Kệ D4'),
    ('S005', 'C006', 'Kệ E5'),
    ('S005', 'C007', 'Kệ E5');





create table DocGia(
	MaDG varchar(10) primary key,
	TenDG nvarchar(100) not null,
	DiaChi nvarchar(255) not null,
	Sdt varchar(15)
);

insert into DocGia (MaDG, TenDG, DiaChi, Sdt) 
values
    ('DG001', 'Nguyen Van A', 'Ha Noi', '0987654321'),
    ('DG002', 'Tran Thi B', 'Ho Chi Minh', '0123456789'),
    ('DG003', 'Le Van C', 'Da Nang', '0345678901'),
    ('DG004', 'Pham Thi D', 'Hai Phong', '0456789012');




create table Muon (
	MaCuon varchar(10) not null,
	MaDG varchar(10) not null,
	NgayMuon Date not null,
	NgayTra Date  null,
	primary key (MaCuon, MaDG),

	foreign key (MaCuon) references CuonSach( MaCuon ) on delete cascade on update cascade,
	foreign key (MaDG) references DocGia(MaDG) on delete cascade on update cascade,

	check( NgayTra is null or NgayTra >= NgayMuon ) --ràng buộc
);

insert into Muon (MaCuon, MaDG, NgayMuon, NgayTra) 
values
    ('C001', 'DG001', '2024-03-01', '2024-03-10'),
    ('C002', 'DG001', '2024-03-05', '2024-03-15'),
    ('C003', 'DG002', '2024-02-20', '2024-03-01'),
    ('C004', 'DG003', '2024-03-10', '2024-03-20'),
    ('C005', 'DG004', '2024-03-12', '2024-03-22'),
    ('C006', 'DG001', '2024-03-15', '2024-03-25'),
    ('C007', 'DG001', '2024-03-18', '2024-03-28');