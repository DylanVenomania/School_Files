﻿-- 23110186 Tôn Hoàng Cầm
create database Cosodulieu_tuan4_QLNhanVien;
go

use Cosodulieu_tuan4_QLNhanVien;
go

create table dbo.PhongBan(
	MaPB int primary key,
	TenPB char( 50 ) null,
	TrPhong char( 4 ) null,
	NgNhanChuc date null 
)
go


Insert into PhongBan  ( MaPB, TenPB, TrPhong, NgNhanChuc )
Values 
(1, 'Nghien cuu', 'nv02', '2013-12-12'),
(2, 'To chuc', 'nv03', '2013-11-21'),
(3, 'Vat tu', 'nv06', '2013-01-25'),
(4, 'Dao tao', 'nv15', '2013-02-19'),
(5, 'Kinh doanh', 'nv15', '2013-08-18'),
(6, 'Doi ngoai', 'nv15', '2013-10-17'),
(7, 'Xay dung', 'nv15', '2013-02-20'),
(8, 'QL Du an', 'nv11', '2013-12-12'),
(9, 'Ke toan', 'nv13', '2013-12-12'),
(10, 'BGD', 'nv15', '2010-11-29');
go


create table dbo.NhanVien(
	MaNV char( 4 ) primary key,
	HoNV char( 10 ) null,
	Tenlot char( 20) null,
	TenNV char( 10) null,
	NgSinh date null,
	Dchi char( 50 ) null,
	Gioitinh char( 3 ) null,
	Luong int null,
	MaNQL char( 4) null,
	Phong int null
)
go


Insert into Nhanvien ( MaNV, HoNV, Tenlot, TenNV, NgSinh, Dchi, Gioitinh, Luong, MaNQL, Phong)
Values 
('nv01', 'Nguyen', 'Ngoc', 'Hoang', '1972-08-13', '111 Vo Van Ngan', 'Nam', 30000, 'NV02', 1),
('nv02', 'Nguyen', 'Quang', 'Ngoc', '1975-08-23', '111 Nguyen Van Troi', 'Nam', 25000, 'NV15', 1),
('nv03', 'Le', 'Thi', 'Ngoc', '1980-08-13', '111 Duong 3/2', 'Nu', 28000, 'NV15', 2),
('nv04', 'Le', 'Ngoc', 'Hoang', '1982-08-18', '111 Le Van Duyet', 'Nam', 15000, 'NV03', 2),
('nv05', 'Nguyen', 'Thi', 'Ngoc', '1992-08-13', '108 Vo Van Ngan', 'Nu', 28000, 'NV06', 3),
('nv06', 'Truong', 'Anh', 'Kiet', '1960-12-13', '11 Hai Ba Trung', 'Nam', 30000, 'NV15', 3),
('nv07', 'Le', 'Phung', 'Hieu', '1972-08-13', '11 Hau Giang', 'Nam', 10000, 'NV15', 4),
('nv08', 'Nguyen', 'Bao', 'Hung', '1978-08-23', '10 Tran Hung Dao', 'Nam', 20000, 'NV15', 5),
('nv09', 'Nguyen', 'Bao', 'Hoang', '1972-08-13', '111 Tran Hung Dao', 'Nam', 10000, 'NV15', 6),
('nv10', 'Le', 'Hoang', 'Ngoc', '1972-08-13', '11 Lac Long Quan', 'Nam', 10000, 'NV15', 7),
('nv11', 'Nguyen', 'Bao','Ngoc', '1972-08-13', '111 Minh Phung', 'Nu', 15000, 'NV15', 8),
('nv12', 'Nguyen', 'Ngoc', 'A', '1982-08-13', '11 Nguyen Duy Trinh', 'Nam', 10000, 'NV11', 8),
('nv13', 'Le', 'Quang', 'Hoang', '1979-08-23', '10 Ly Chinh Thang', 'Nam', 15000, 'NV15', 9),
('nv14', 'Nguyen', 'Quang', 'Hoang', '1972-08-13', '11 Le Van Thinh', 'Nam', 10000, 'NV13', 9),
('nv15', 'Dang', 'Tan', 'Dung', '1960-08-13', '23 Vo Van Ngan', 'Nam', 50000, NULL, 10);
Go



alter table NhanVien with check add foreign key(MaNQL) references NhanVien(MaNV) 
go

alter table NhanVien with check add foreign key( Phong ) references PhongBan(MaPB)
go


create table Diadiem_Phong(
	MaPB int references PhongBan( MaPB),
	DiaDiem char(50),
	Primary key ( MaPB, DiaDiem )
)
go


Insert into Diadiem_Phong( MaPB, DiaDiem)
Values
(1, 'Tang tret - Khu A'),
(2, 'Tang 1 - Khu A'),
(3, 'Tang tret - Khu B'),
(4, 'Tang tret - Khu C'),
(5, 'Tang tret - Khu E'),
(6, 'Tang tret - Khu Bat Giac'),
(7, 'Tang tret - Khu Trung Tam'),
(8, 'Tang 1 - Khu Trung Tam'),
(9, 'Tang 2 - Khu Trung Tam'),
(10, 'Tang 3 - Khu Trung Tam');
Go



create table Duan(
	MaDA char( 4) primary key,
	TenDA char( 50 ),
	DiaDiem char( 50 ),
	Phong int references PhongBan( MaPB )
)
go


Insert into Duan 
Values 
('DA01', 'Cap thoat nuoc', 'Go Vap', 9),
('DA02', 'Ban chung cu', 'Thu Thiem', 5),
('DA03', 'Xay biet thu', 'Thu Duc', 7),
('DA04', 'Lien ket dao tao', 'Go Vap', 4),
('DA05', 'Cung cap vat tu', 'Quan 2', 3),
('DA06', 'Huan luyen', 'Go Vap', 4);
Go



create table PhanCong(
	MaNV char(4) references NhanVien(MaNV),
	MaDA char (4) references Duan( MaDA ),
	ThoiGian int,
	Primary key ( MaNV, MaDA )
)
go


Insert into PhanCong (MaNV, MaDA, ThoiGian)
Values 
('nv01', 'DA01', 3),
('nv01', 'DA02', 3),
('nv02', 'DA01', 3),
('nv02', 'DA03', 3),
('nv03', 'DA04', 3),
('nv04', 'DA03', 3),
('nv09', 'DA04', 3),
('nv01', 'DA05', 3),
('nv05', 'DA05', 3),
('nv07', 'DA06', 3),
('nv08', 'DA06', 3);
Go



create table ThanNhan(
	MaNV char(4) references NhanVien( MaNV),
	TenTN char( 20),
	GioiTinh char( 3 ), 
	NgaySinh date ,
	QuanHe char( 10 ),
	primary key ( MaNV, TenTN)
)
go


Insert into ThanNhan 
Values 
('nv01', 'Nguyen Ngoc Huy', 'Nam', '2018-03-26','con'),
('nv01', 'Nguyen Ngoc Hoa', 'Nu', '2020-03-26','con'),
('nv02', 'Nguyen Ngoc Huy', 'Nam', '2018-03-26','con'),
('nv02', 'Nguyen Ngoc Hoa', 'Nu', '2020-03-26','con'),
('nv15', 'Dang Ngoc Hoa', 'Nu', '2020-03-26','con'),
('nv01', 'Nguyen Nguyen Hung', 'Nam', '2020-03-26','con');

