﻿-- 23110186 Tôn Hoàng Cầm
create database Cosodulieu_tuan4_QLNhanVienCoQuan;
go

use Cosodulieu_tuan4_QLNhanVienCoQuan;
go


create table coquan (
    mscoquan int primary key,
    tencoquan nvarchar(255) not null,
    diachi nvarchar(255) not null
);


create table nv (
    msnv int primary key,
    ten nvarchar(255) not null,
    mscoquan int not null,
    congviec nvarchar(255),
    luong decimal(10,2),
    foreign key (mscoquan) references coquan(mscoquan) 
    on delete cascade on update cascade

);

insert into coquan (mscoquan, tencoquan, diachi) 
values
(50, 'cong ty a', 'Ha Noi'),
(15, 'cong ty b', 'Hai Phong'),
(20, 'cong ty c', 'Da Nang'),
(25, 'cong ty d', 'Tp.HCM'),
(30, 'cong ty e', 'Do Son');

-- thêm dữ liệu vào bảng nv
insert into nv (msnv, ten, mscoquan, congviec, luong) 
values
(101, 'Nguyen Van An', 50, 'ke toan', 1000.00),
(102, 'Tran Thi B', 15, 'lap trinh vien', 1500.00),
(103, 'Le Van C', 20, 'thiet ke do hoa', 1200.00),
(104, 'Pham Thi D', 25, 'quan ly', 2000.00),
(105, 'Hoang Van E', 50, 'nhan su', 1100.00),
(106, 'Vu Thi F', 30, 'bao ve', 800.00),
(107, 'Dinh Van G', 30, 'nhan vien hanh chinh', 900.00);

