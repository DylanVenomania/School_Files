﻿namespace QLVatTu
{
    partial class frm_qlvattu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_mavt = new System.Windows.Forms.TextBox();
            this.txt_tenvt = new System.Windows.Forms.TextBox();
            this.txt_nhasx = new System.Windows.Forms.TextBox();
            this.dtp_ngaysx = new System.Windows.Forms.DateTimePicker();
            this.txt_hansd = new System.Windows.Forms.TextBox();
            this.txt_soluong = new System.Windows.Forms.TextBox();
            this.txt_dongia = new System.Windows.Forms.TextBox();
            this.btn_them = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.dgv_vattu = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_vattu)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã vật tư";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên vật tư";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(436, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Hạn sử dụng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Nhà sản xuất";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(56, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Ngày sản xuất";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(436, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Số lượng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(436, 153);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 16);
            this.label7.TabIndex = 2;
            this.label7.Text = "Đơn giá";
            // 
            // txt_mavt
            // 
            this.txt_mavt.Location = new System.Drawing.Point(170, 35);
            this.txt_mavt.Name = "txt_mavt";
            this.txt_mavt.Size = new System.Drawing.Size(189, 22);
            this.txt_mavt.TabIndex = 3;
            // 
            // txt_tenvt
            // 
            this.txt_tenvt.Location = new System.Drawing.Point(170, 91);
            this.txt_tenvt.Name = "txt_tenvt";
            this.txt_tenvt.Size = new System.Drawing.Size(189, 22);
            this.txt_tenvt.TabIndex = 3;
            // 
            // txt_nhasx
            // 
            this.txt_nhasx.Location = new System.Drawing.Point(170, 147);
            this.txt_nhasx.Name = "txt_nhasx";
            this.txt_nhasx.Size = new System.Drawing.Size(189, 22);
            this.txt_nhasx.TabIndex = 3;
            // 
            // dtp_ngaysx
            // 
            this.dtp_ngaysx.Location = new System.Drawing.Point(170, 207);
            this.dtp_ngaysx.Name = "dtp_ngaysx";
            this.dtp_ngaysx.Size = new System.Drawing.Size(189, 22);
            this.dtp_ngaysx.TabIndex = 4;
            // 
            // txt_hansd
            // 
            this.txt_hansd.Location = new System.Drawing.Point(554, 38);
            this.txt_hansd.Name = "txt_hansd";
            this.txt_hansd.Size = new System.Drawing.Size(189, 22);
            this.txt_hansd.TabIndex = 3;
            // 
            // txt_soluong
            // 
            this.txt_soluong.Location = new System.Drawing.Point(554, 94);
            this.txt_soluong.Name = "txt_soluong";
            this.txt_soluong.Size = new System.Drawing.Size(189, 22);
            this.txt_soluong.TabIndex = 3;
            // 
            // txt_dongia
            // 
            this.txt_dongia.Location = new System.Drawing.Point(554, 150);
            this.txt_dongia.Name = "txt_dongia";
            this.txt_dongia.Size = new System.Drawing.Size(189, 22);
            this.txt_dongia.TabIndex = 3;
            // 
            // btn_them
            // 
            this.btn_them.Location = new System.Drawing.Point(211, 270);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(104, 33);
            this.btn_them.TabIndex = 5;
            this.btn_them.Text = "Thêm";
            this.btn_them.UseVisualStyleBackColor = true;
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(360, 270);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(104, 33);
            this.btnSua.TabIndex = 5;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(519, 270);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(104, 33);
            this.btnXoa.TabIndex = 5;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(668, 270);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(104, 33);
            this.btnThoat.TabIndex = 5;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // dgv_vattu
            // 
            this.dgv_vattu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_vattu.Location = new System.Drawing.Point(59, 327);
            this.dgv_vattu.Name = "dgv_vattu";
            this.dgv_vattu.RowHeadersWidth = 51;
            this.dgv_vattu.RowTemplate.Height = 24;
            this.dgv_vattu.Size = new System.Drawing.Size(871, 195);
            this.dgv_vattu.TabIndex = 6;
            this.dgv_vattu.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_vattu_CellClick);
            // 
            // frm_qlvattu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 553);
            this.Controls.Add(this.dgv_vattu);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btn_them);
            this.Controls.Add(this.dtp_ngaysx);
            this.Controls.Add(this.txt_dongia);
            this.Controls.Add(this.txt_nhasx);
            this.Controls.Add(this.txt_soluong);
            this.Controls.Add(this.txt_tenvt);
            this.Controls.Add(this.txt_hansd);
            this.Controls.Add(this.txt_mavt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frm_qlvattu";
            this.Text = "Quản lý vật tư";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_vattu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_mavt;
        private System.Windows.Forms.TextBox txt_tenvt;
        private System.Windows.Forms.TextBox txt_nhasx;
        private System.Windows.Forms.DateTimePicker dtp_ngaysx;
        private System.Windows.Forms.TextBox txt_hansd;
        private System.Windows.Forms.TextBox txt_soluong;
        private System.Windows.Forms.TextBox txt_dongia;
        private System.Windows.Forms.Button btn_them;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.DataGridView dgv_vattu;
    }
}